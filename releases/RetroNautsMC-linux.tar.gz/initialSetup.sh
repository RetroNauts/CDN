sudo cp -r  jre8-RetroNautsMC/ /usr/lib/jvm/
