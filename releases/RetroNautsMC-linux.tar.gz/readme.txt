For Linux Users:

1) Run the initial setup via "sh initalSetup.sh".
2) Run the launcher via "java -jar Retronauts.jar".
3) Install the pack of choice.
4) Right click the pack and select custom Java and select the one that says "jre8-RetroNautsMC"
5) Enjoy

